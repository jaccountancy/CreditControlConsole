# system configuration generated and used by the sysconfig module
build_time_vars = {'ABIFLAGS': '',
 'AC_APPLE_UNIVERSAL_BUILD': 0,
 'AIX_BUILDDATE': 0,
 'AIX_GENUINE_CPLUSPLUS': 0,
 'ALIGNOF_LONG': 8,
 'ALIGNOF_SIZE_T': 8,
 'ALT_SOABI': 0,
 'ANDROID_API_LEVEL': 0,
 'AR': '/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/tools/llvm/bin/llvm-ar',
 'ARFLAGS': 'rcs',
 'BASECFLAGS': '',
 'BASECPPFLAGS': '',
 'BASEMODLIBS': '',
 'BINDIR': '/install/bin',
 'BINLIBDEST': '/install/lib/python3.11',
 'BLDLIBRARY': '-L. -lpython3.11',
 'BLDSHARED': 'clang -bundle -undefined dynamic_lookup -arch arm64 '
              '-mmacosx-version-min=11.0 -isysroot '
              '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
              '',
 'BOOTSTRAP_HEADERS': '\\',
 'BUILDEXE': '.exe',
 'BUILDPYTHON': 'python.exe',
 'BUILD_GNU_TYPE': 'aarch64-apple-darwin',
 'BYTESTR_DEPS': '\\',
 'CC': 'clang',
 'CCSHARED': '',
 'CFLAGS': '-DNDEBUG -g -fwrapv -O3 -Wall -arch arm64 '
           '-mmacosx-version-min=11.0 -Wno-nullability-completeness '
           '-Wno-expansion-to-defined -Wno-undef-prefix  -isysroot '
           '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
           '-fPIC '
           ' '
           ' '
           ' '
           '-Werror=unguarded-availability-new',
 'CFLAGSFORSHARED': '',
 'CFLAGS_ALIASING': '-fno-strict-aliasing',
 'CONFIGFILES': 'configure configure.ac acconfig.h pyconfig.h.in '
                'Makefile.pre.in',
 'CONFIGURE_CFLAGS': '-arch arm64 -mmacosx-version-min=11.0 '
                     '-Wno-nullability-completeness -Wno-expansion-to-defined '
                     '-Wno-undef-prefix  -isysroot '
                     '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                     '-fPIC '
                     ' '
                     ' '
                     ' '
                     '-Werror=unguarded-availability-new',
 'CONFIGURE_CFLAGS_NODIST': '-flto -std=c11 '
                            '-Werror=implicit-function-declaration '
                            '-fvisibility=hidden',
 'CONFIGURE_CPPFLAGS': '-arch arm64 -mmacosx-version-min=11.0 '
                       '-Wno-nullability-completeness '
                       '-Wno-expansion-to-defined -Wno-undef-prefix  -isysroot '
                       '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                       '-fPIC '
                       ' '
                       ' '
                       ' '
                       '-Werror=unguarded-availability-new',
 'CONFIGURE_LDFLAGS': '-arch arm64 -mmacosx-version-min=11.0 -isysroot '
                      '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                      '',
 'CONFIGURE_LDFLAGS_NODIST': '-flto -Wl,-export_dynamic -g',
 'CONFIGURE_LDFLAGS_NOLTO': '-flto=thin',
 'CONFIG_ARGS': "'--build=aarch64-apple-darwin' '--host=aarch64-apple-darwin' "
                "'--prefix=/install' "
                "'--with-openssl=/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/tools/deps' "
                "'--with-system-expat' '--with-system-libmpdec' "
                "'--without-ensurepip' '--enable-shared' "
                "'--enable-optimizations' '--with-lto' "
                "'--with-build-python=/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/tools/host/bin/python3.11' "
                "'ac_cv_lib_intl_textdomain=no' 'ac_cv_func_ptsname_r=no' "
                "'--with-dbmliborder=ndbm' 'build_alias=aarch64-apple-darwin' "
                "'host_alias=aarch64-apple-darwin' 'CC=clang' 'CFLAGS=-arch "
                'arm64 -mmacosx-version-min=11.0 -Wno-nullability-completeness '
                '-Wno-expansion-to-defined -Wno-undef-prefix  -isysroot '
                '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                '-fPIC '
                ' '
                ' '
                ' '
                "-Werror=unguarded-availability-new' 'LDFLAGS=-arch arm64 "
                '-mmacosx-version-min=11.0 -isysroot '
                '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                "' "
                "'CPPFLAGS=-arch arm64 -mmacosx-version-min=11.0 "
                '-Wno-nullability-completeness -Wno-expansion-to-defined '
                '-Wno-undef-prefix  -isysroot '
                '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                '-fPIC '
                ' '
                ' '
                ' '
                "-Werror=unguarded-availability-new'",
 'CONFINCLUDEDIR': '/install/include',
 'CONFINCLUDEPY': '/install/include/python3.11',
 'COREPYTHONPATH': '',
 'COVERAGE_INFO': '/private/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/Python-3.11.10/coverage.info',
 'COVERAGE_LCOV_OPTIONS': '--rc lcov_branch_coverage=1',
 'COVERAGE_REPORT': '/private/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/Python-3.11.10/lcov-report',
 'COVERAGE_REPORT_OPTIONS': '--rc lcov_branch_coverage=1 --branch-coverage '
                            '--title "CPython 3.11 LCOV report [commit $(shell '
                            ')]"',
 'CPPFLAGS': '-I. -I./Include -arch arm64 -mmacosx-version-min=11.0 '
             '-Wno-nullability-completeness -Wno-expansion-to-defined '
             '-Wno-undef-prefix  -isysroot '
             '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
             '-fPIC '
             ' '
             ' '
             ' '
             '-Werror=unguarded-availability-new',
 'CXX': 'clang++',
 'DECIMAL_CFLAGS': '-DUNIVERSAL=1',
 'DECIMAL_LDFLAGS': '-lmpdec',
 'DEEPFREEZE_C': 'Python/deepfreeze/deepfreeze.c',
 'DEEPFREEZE_DEPS': './Tools/scripts/deepfreeze.py '
                    './Programs/_freeze_module.py \\',
 'DEEPFREEZE_OBJS': 'Python/deepfreeze/deepfreeze.o',
 'DESTDIRS': '/install /install/lib /install/lib/python3.11 '
             '/install/lib/python3.11/lib-dynload',
 'DESTLIB': '/install/lib/python3.11',
 'DESTPATH': '',
 'DESTSHARED': '/install/lib/python3.11/lib-dynload',
 'DFLAGS': '',
 'DIRMODE': 755,
 'DIST': 'README.rst ChangeLog configure configure.ac acconfig.h pyconfig.h.in '
         'Makefile.pre.in Include Lib Misc Ext-dummy',
 'DISTDIRS': 'Include Lib Misc Ext-dummy',
 'DISTFILES': 'README.rst ChangeLog configure configure.ac acconfig.h '
              'pyconfig.h.in Makefile.pre.in',
 'DLINCLDIR': '.',
 'DLLLIBRARY': '',
 'DOUBLE_IS_ARM_MIXED_ENDIAN_IEEE754': 0,
 'DOUBLE_IS_BIG_ENDIAN_IEEE754': 0,
 'DOUBLE_IS_LITTLE_ENDIAN_IEEE754': 1,
 'DTRACE': '',
 'DTRACE_DEPS': '\\',
 'DTRACE_HEADERS': '',
 'DTRACE_OBJS': '',
 'DYNLOADFILE': 'dynload_shlib.o',
 'ENABLE_IPV6': 1,
 'ENSUREPIP': 'no',
 'EXE': '',
 'EXEMODE': 755,
 'EXPAT_CFLAGS': '',
 'EXPAT_LDFLAGS': '-lexpat',
 'EXPORTSFROM': '',
 'EXPORTSYMS': '',
 'EXTRATESTOPTS': '',
 'EXTRA_CFLAGS': '',
 'EXT_SUFFIX': '.cpython-311-darwin.so',
 'FILEMODE': 644,
 'FLOAT_WORDS_BIGENDIAN': 0,
 'FREEZE_MODULE': '/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/tools/host/bin/python3.11 '
                  './Programs/_freeze_module.py',
 'FREEZE_MODULE_BOOTSTRAP': '/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/tools/host/bin/python3.11 '
                            './Programs/_freeze_module.py',
 'FREEZE_MODULE_BOOTSTRAP_DEPS': './Programs/_freeze_module.py',
 'FREEZE_MODULE_DEPS': './Programs/_freeze_module.py',
 'FROZEN_FILES_IN': '\\',
 'FROZEN_FILES_OUT': '\\',
 'GETPGRP_HAVE_ARG': 0,
 'GITBRANCH': '',
 'GITTAG': '',
 'GITVERSION': '',
 'GNULD': 'no',
 'HAVE_ACCEPT': 1,
 'HAVE_ACCEPT4': 0,
 'HAVE_ACOSH': 1,
 'HAVE_ADDRINFO': 1,
 'HAVE_ALARM': 1,
 'HAVE_ALIGNED_REQUIRED': 0,
 'HAVE_ALLOCA_H': 1,
 'HAVE_ALTZONE': 0,
 'HAVE_ASINH': 1,
 'HAVE_ASM_TYPES_H': 0,
 'HAVE_ATANH': 1,
 'HAVE_BIND': 1,
 'HAVE_BIND_TEXTDOMAIN_CODESET': 0,
 'HAVE_BLUETOOTH_BLUETOOTH_H': 0,
 'HAVE_BLUETOOTH_H': 0,
 'HAVE_BROKEN_MBSTOWCS': 0,
 'HAVE_BROKEN_NICE': 0,
 'HAVE_BROKEN_PIPE_BUF': 0,
 'HAVE_BROKEN_POLL': 0,
 'HAVE_BROKEN_POSIX_SEMAPHORES': 0,
 'HAVE_BROKEN_PTHREAD_SIGMASK': 0,
 'HAVE_BROKEN_SEM_GETVALUE': 1,
 'HAVE_BROKEN_UNSETENV': 0,
 'HAVE_BUILTIN_ATOMIC': 1,
 'HAVE_BZLIB_H': 1,
 'HAVE_CHFLAGS': 1,
 'HAVE_CHMOD': 1,
 'HAVE_CHOWN': 1,
 'HAVE_CHROOT': 1,
 'HAVE_CLOCK': 1,
 'HAVE_CLOCK_GETRES': 1,
 'HAVE_CLOCK_GETTIME': 1,
 'HAVE_CLOCK_NANOSLEEP': 0,
 'HAVE_CLOCK_SETTIME': 1,
 'HAVE_CLOSE_RANGE': 0,
 'HAVE_COMPUTED_GOTOS': 1,
 'HAVE_CONFSTR': 1,
 'HAVE_CONIO_H': 0,
 'HAVE_CONNECT': 1,
 'HAVE_COPY_FILE_RANGE': 0,
 'HAVE_CRYPT_H': 0,
 'HAVE_CRYPT_R': 0,
 'HAVE_CTERMID': 1,
 'HAVE_CTERMID_R': 1,
 'HAVE_CURSES_FILTER': 1,
 'HAVE_CURSES_H': 1,
 'HAVE_CURSES_HAS_KEY': 1,
 'HAVE_CURSES_IMMEDOK': 1,
 'HAVE_CURSES_IS_PAD': 0,
 'HAVE_CURSES_IS_TERM_RESIZED': 1,
 'HAVE_CURSES_RESIZETERM': 1,
 'HAVE_CURSES_RESIZE_TERM': 1,
 'HAVE_CURSES_SYNCOK': 1,
 'HAVE_CURSES_TYPEAHEAD': 1,
 'HAVE_CURSES_USE_ENV': 1,
 'HAVE_CURSES_WCHGAT': 1,
 'HAVE_DB_H': 1,
 'HAVE_DECL_RTLD_DEEPBIND': 0,
 'HAVE_DECL_RTLD_GLOBAL': 1,
 'HAVE_DECL_RTLD_LAZY': 1,
 'HAVE_DECL_RTLD_LOCAL': 1,
 'HAVE_DECL_RTLD_MEMBER': 0,
 'HAVE_DECL_RTLD_NODELETE': 1,
 'HAVE_DECL_RTLD_NOLOAD': 1,
 'HAVE_DECL_RTLD_NOW': 1,
 'HAVE_DECL_TZNAME': 0,
 'HAVE_DEVICE_MACROS': 1,
 'HAVE_DEV_PTC': 0,
 'HAVE_DEV_PTMX': 1,
 'HAVE_DIRECT_H': 0,
 'HAVE_DIRENT_D_TYPE': 1,
 'HAVE_DIRENT_H': 1,
 'HAVE_DIRFD': 1,
 'HAVE_DLFCN_H': 1,
 'HAVE_DLOPEN': 1,
 'HAVE_DUP': 1,
 'HAVE_DUP2': 1,
 'HAVE_DUP3': 0,
 'HAVE_DYLD_SHARED_CACHE_CONTAINS_PATH': 1,
 'HAVE_DYNAMIC_LOADING': 1,
 'HAVE_ENDIAN_H': 0,
 'HAVE_EPOLL': 0,
 'HAVE_EPOLL_CREATE1': 0,
 'HAVE_ERF': 1,
 'HAVE_ERFC': 1,
 'HAVE_ERRNO_H': 1,
 'HAVE_EVENTFD': 0,
 'HAVE_EXECV': 1,
 'HAVE_EXPLICIT_BZERO': 0,
 'HAVE_EXPLICIT_MEMSET': 0,
 'HAVE_EXPM1': 1,
 'HAVE_FACCESSAT': 1,
 'HAVE_FCHDIR': 1,
 'HAVE_FCHMOD': 1,
 'HAVE_FCHMODAT': 1,
 'HAVE_FCHOWN': 1,
 'HAVE_FCHOWNAT': 1,
 'HAVE_FCNTL_H': 1,
 'HAVE_FDATASYNC': 0,
 'HAVE_FDOPENDIR': 1,
 'HAVE_FDWALK': 0,
 'HAVE_FEXECVE': 0,
 'HAVE_FLOCK': 1,
 'HAVE_FORK': 1,
 'HAVE_FORK1': 0,
 'HAVE_FORKPTY': 1,
 'HAVE_FPATHCONF': 1,
 'HAVE_FSEEK64': 0,
 'HAVE_FSEEKO': 1,
 'HAVE_FSTATAT': 1,
 'HAVE_FSTATVFS': 1,
 'HAVE_FSYNC': 1,
 'HAVE_FTELL64': 0,
 'HAVE_FTELLO': 1,
 'HAVE_FTIME': 1,
 'HAVE_FTRUNCATE': 1,
 'HAVE_FUTIMENS': 1,
 'HAVE_FUTIMES': 1,
 'HAVE_FUTIMESAT': 0,
 'HAVE_GAI_STRERROR': 1,
 'HAVE_GCC_ASM_FOR_MC68881': 0,
 'HAVE_GCC_ASM_FOR_X64': 0,
 'HAVE_GCC_ASM_FOR_X87': 0,
 'HAVE_GCC_UINT128_T': 1,
 'HAVE_GDBM_DASH_NDBM_H': 0,
 'HAVE_GDBM_H': 0,
 'HAVE_GDBM_NDBM_H': 0,
 'HAVE_GETADDRINFO': 1,
 'HAVE_GETC_UNLOCKED': 1,
 'HAVE_GETEGID': 1,
 'HAVE_GETENTROPY': 1,
 'HAVE_GETEUID': 1,
 'HAVE_GETGID': 1,
 'HAVE_GETGRGID': 1,
 'HAVE_GETGRGID_R': 1,
 'HAVE_GETGRNAM_R': 1,
 'HAVE_GETGROUPLIST': 1,
 'HAVE_GETGROUPS': 1,
 'HAVE_GETHOSTBYADDR': 1,
 'HAVE_GETHOSTBYNAME': 1,
 'HAVE_GETHOSTBYNAME_R': 0,
 'HAVE_GETHOSTBYNAME_R_3_ARG': 0,
 'HAVE_GETHOSTBYNAME_R_5_ARG': 0,
 'HAVE_GETHOSTBYNAME_R_6_ARG': 0,
 'HAVE_GETHOSTNAME': 1,
 'HAVE_GETITIMER': 1,
 'HAVE_GETLOADAVG': 1,
 'HAVE_GETLOGIN': 1,
 'HAVE_GETNAMEINFO': 1,
 'HAVE_GETPAGESIZE': 1,
 'HAVE_GETPEERNAME': 1,
 'HAVE_GETPGID': 1,
 'HAVE_GETPGRP': 1,
 'HAVE_GETPID': 1,
 'HAVE_GETPPID': 1,
 'HAVE_GETPRIORITY': 1,
 'HAVE_GETPROTOBYNAME': 1,
 'HAVE_GETPWENT': 1,
 'HAVE_GETPWNAM_R': 1,
 'HAVE_GETPWUID': 1,
 'HAVE_GETPWUID_R': 1,
 'HAVE_GETRANDOM': 0,
 'HAVE_GETRANDOM_SYSCALL': 0,
 'HAVE_GETRESGID': 0,
 'HAVE_GETRESUID': 0,
 'HAVE_GETRUSAGE': 1,
 'HAVE_GETSERVBYNAME': 1,
 'HAVE_GETSERVBYPORT': 1,
 'HAVE_GETSID': 1,
 'HAVE_GETSOCKNAME': 1,
 'HAVE_GETSPENT': 0,
 'HAVE_GETSPNAM': 0,
 'HAVE_GETUID': 1,
 'HAVE_GETWD': 1,
 'HAVE_GLIBC_MEMMOVE_BUG': 0,
 'HAVE_GRP_H': 1,
 'HAVE_HSTRERROR': 1,
 'HAVE_HTOLE64': 0,
 'HAVE_IEEEFP_H': 0,
 'HAVE_IF_NAMEINDEX': 1,
 'HAVE_INET_ATON': 1,
 'HAVE_INET_NTOA': 1,
 'HAVE_INET_PTON': 1,
 'HAVE_INITGROUPS': 1,
 'HAVE_INTTYPES_H': 1,
 'HAVE_IO_H': 0,
 'HAVE_IPA_PURE_CONST_BUG': 0,
 'HAVE_KILL': 1,
 'HAVE_KILLPG': 1,
 'HAVE_KQUEUE': 1,
 'HAVE_LANGINFO_H': 1,
 'HAVE_LARGEFILE_SUPPORT': 0,
 'HAVE_LCHFLAGS': 1,
 'HAVE_LCHMOD': 1,
 'HAVE_LCHOWN': 1,
 'HAVE_LIBB2': 0,
 'HAVE_LIBDB': 0,
 'HAVE_LIBDL': 1,
 'HAVE_LIBDLD': 0,
 'HAVE_LIBGDBM_COMPAT': 0,
 'HAVE_LIBIEEE': 0,
 'HAVE_LIBINTL_H': 0,
 'HAVE_LIBNDBM': 0,
 'HAVE_LIBREADLINE': 1,
 'HAVE_LIBRESOLV': 0,
 'HAVE_LIBSENDFILE': 0,
 'HAVE_LIBSQLITE3': 1,
 'HAVE_LIBUTIL_H': 0,
 'HAVE_LINK': 1,
 'HAVE_LINKAT': 1,
 'HAVE_LINUX_AUXVEC_H': 0,
 'HAVE_LINUX_CAN_BCM_H': 0,
 'HAVE_LINUX_CAN_H': 0,
 'HAVE_LINUX_CAN_J1939_H': 0,
 'HAVE_LINUX_CAN_RAW_FD_FRAMES': 0,
 'HAVE_LINUX_CAN_RAW_H': 0,
 'HAVE_LINUX_CAN_RAW_JOIN_FILTERS': 0,
 'HAVE_LINUX_LIMITS_H': 0,
 'HAVE_LINUX_MEMFD_H': 0,
 'HAVE_LINUX_NETLINK_H': 0,
 'HAVE_LINUX_QRTR_H': 0,
 'HAVE_LINUX_RANDOM_H': 0,
 'HAVE_LINUX_SOUNDCARD_H': 0,
 'HAVE_LINUX_TIPC_H': 0,
 'HAVE_LINUX_VM_SOCKETS_H': 0,
 'HAVE_LINUX_WAIT_H': 0,
 'HAVE_LISTEN': 1,
 'HAVE_LOCKF': 1,
 'HAVE_LOG1P': 1,
 'HAVE_LOG2': 1,
 'HAVE_LOGIN_TTY': 1,
 'HAVE_LONG_DOUBLE': 1,
 'HAVE_LSTAT': 1,
 'HAVE_LUTIMES': 1,
 'HAVE_LZMA_H': 1,
 'HAVE_MADVISE': 1,
 'HAVE_MAKEDEV': 1,
 'HAVE_MBRTOWC': 1,
 'HAVE_MEMFD_CREATE': 0,
 'HAVE_MEMORY_H': 0,
 'HAVE_MEMRCHR': 0,
 'HAVE_MKDIRAT': 1,
 'HAVE_MKFIFO': 1,
 'HAVE_MKFIFOAT': 1,
 'HAVE_MKNOD': 1,
 'HAVE_MKNODAT': 1,
 'HAVE_MKTIME': 1,
 'HAVE_MMAP': 1,
 'HAVE_MREMAP': 0,
 'HAVE_NANOSLEEP': 1,
 'HAVE_NCURSES_H': 1,
 'HAVE_NDBM_H': 1,
 'HAVE_NDIR_H': 0,
 'HAVE_NETCAN_CAN_H': 0,
 'HAVE_NETDB_H': 1,
 'HAVE_NETINET_IN_H': 1,
 'HAVE_NETPACKET_PACKET_H': 0,
 'HAVE_NET_IF_H': 1,
 'HAVE_NICE': 1,
 'HAVE_NON_UNICODE_WCHAR_T_REPRESENTATION': 0,
 'HAVE_OPENAT': 1,
 'HAVE_OPENDIR': 1,
 'HAVE_OPENPTY': 1,
 'HAVE_PATHCONF': 1,
 'HAVE_PAUSE': 1,
 'HAVE_PIPE': 1,
 'HAVE_PIPE2': 0,
 'HAVE_PLOCK': 0,
 'HAVE_POLL': 1,
 'HAVE_POLL_H': 1,
 'HAVE_POSIX_FADVISE': 0,
 'HAVE_POSIX_FALLOCATE': 0,
 'HAVE_POSIX_SPAWN': 1,
 'HAVE_POSIX_SPAWNP': 1,
 'HAVE_PREAD': 1,
 'HAVE_PREADV': 1,
 'HAVE_PREADV2': 0,
 'HAVE_PRLIMIT': 0,
 'HAVE_PROCESS_H': 0,
 'HAVE_PROTOTYPES': 1,
 'HAVE_PTHREAD_CONDATTR_SETCLOCK': 0,
 'HAVE_PTHREAD_DESTRUCTOR': 0,
 'HAVE_PTHREAD_GETCPUCLOCKID': 0,
 'HAVE_PTHREAD_H': 1,
 'HAVE_PTHREAD_INIT': 0,
 'HAVE_PTHREAD_KILL': 1,
 'HAVE_PTHREAD_SIGMASK': 1,
 'HAVE_PTHREAD_STUBS': 0,
 'HAVE_PTY_H': 0,
 'HAVE_PWRITE': 1,
 'HAVE_PWRITEV': 1,
 'HAVE_PWRITEV2': 0,
 'HAVE_READLINK': 1,
 'HAVE_READLINKAT': 1,
 'HAVE_READV': 1,
 'HAVE_REALPATH': 1,
 'HAVE_RECVFROM': 1,
 'HAVE_RENAMEAT': 1,
 'HAVE_RL_APPEND_HISTORY': 0,
 'HAVE_RL_CATCH_SIGNAL': 0,
 'HAVE_RL_COMPDISP_FUNC_T': 0,
 'HAVE_RL_COMPLETION_APPEND_CHARACTER': 1,
 'HAVE_RL_COMPLETION_DISPLAY_MATCHES_HOOK': 1,
 'HAVE_RL_COMPLETION_MATCHES': 1,
 'HAVE_RL_COMPLETION_SUPPRESS_APPEND': 0,
 'HAVE_RL_PRE_INPUT_HOOK': 1,
 'HAVE_RL_RESIZE_TERMINAL': 0,
 'HAVE_RPC_RPC_H': 1,
 'HAVE_RTPSPAWN': 0,
 'HAVE_SCHED_GET_PRIORITY_MAX': 1,
 'HAVE_SCHED_H': 1,
 'HAVE_SCHED_RR_GET_INTERVAL': 0,
 'HAVE_SCHED_SETAFFINITY': 0,
 'HAVE_SCHED_SETPARAM': 0,
 'HAVE_SCHED_SETSCHEDULER': 0,
 'HAVE_SEM_CLOCKWAIT': 0,
 'HAVE_SEM_GETVALUE': 1,
 'HAVE_SEM_OPEN': 1,
 'HAVE_SEM_TIMEDWAIT': 0,
 'HAVE_SEM_UNLINK': 1,
 'HAVE_SENDFILE': 1,
 'HAVE_SENDTO': 1,
 'HAVE_SETEGID': 1,
 'HAVE_SETEUID': 1,
 'HAVE_SETGID': 1,
 'HAVE_SETGROUPS': 1,
 'HAVE_SETHOSTNAME': 1,
 'HAVE_SETITIMER': 1,
 'HAVE_SETJMP_H': 1,
 'HAVE_SETLOCALE': 1,
 'HAVE_SETPGID': 1,
 'HAVE_SETPGRP': 1,
 'HAVE_SETPRIORITY': 1,
 'HAVE_SETREGID': 1,
 'HAVE_SETRESGID': 0,
 'HAVE_SETRESUID': 0,
 'HAVE_SETREUID': 1,
 'HAVE_SETSID': 1,
 'HAVE_SETSOCKOPT': 1,
 'HAVE_SETUID': 1,
 'HAVE_SETVBUF': 1,
 'HAVE_SHADOW_H': 0,
 'HAVE_SHM_OPEN': 1,
 'HAVE_SHM_UNLINK': 1,
 'HAVE_SHUTDOWN': 1,
 'HAVE_SIGACTION': 1,
 'HAVE_SIGALTSTACK': 1,
 'HAVE_SIGFILLSET': 1,
 'HAVE_SIGINFO_T_SI_BAND': 1,
 'HAVE_SIGINTERRUPT': 1,
 'HAVE_SIGNAL_H': 1,
 'HAVE_SIGPENDING': 1,
 'HAVE_SIGRELSE': 1,
 'HAVE_SIGTIMEDWAIT': 0,
 'HAVE_SIGWAIT': 1,
 'HAVE_SIGWAITINFO': 0,
 'HAVE_SNPRINTF': 1,
 'HAVE_SOCKADDR_ALG': 0,
 'HAVE_SOCKADDR_SA_LEN': 1,
 'HAVE_SOCKADDR_STORAGE': 1,
 'HAVE_SOCKET': 1,
 'HAVE_SOCKETPAIR': 1,
 'HAVE_SPAWN_H': 1,
 'HAVE_SPLICE': 0,
 'HAVE_SSIZE_T': 1,
 'HAVE_STATVFS': 1,
 'HAVE_STAT_TV_NSEC': 0,
 'HAVE_STAT_TV_NSEC2': 1,
 'HAVE_STDARG_PROTOTYPES': 1,
 'HAVE_STDINT_H': 1,
 'HAVE_STDLIB_H': 1,
 'HAVE_STD_ATOMIC': 1,
 'HAVE_STRFTIME': 1,
 'HAVE_STRINGS_H': 1,
 'HAVE_STRING_H': 1,
 'HAVE_STRLCPY': 1,
 'HAVE_STROPTS_H': 0,
 'HAVE_STRSIGNAL': 1,
 'HAVE_STRUCT_PASSWD_PW_GECOS': 1,
 'HAVE_STRUCT_PASSWD_PW_PASSWD': 1,
 'HAVE_STRUCT_STAT_ST_BIRTHTIME': 1,
 'HAVE_STRUCT_STAT_ST_BLKSIZE': 1,
 'HAVE_STRUCT_STAT_ST_BLOCKS': 1,
 'HAVE_STRUCT_STAT_ST_FLAGS': 1,
 'HAVE_STRUCT_STAT_ST_GEN': 1,
 'HAVE_STRUCT_STAT_ST_RDEV': 1,
 'HAVE_STRUCT_TM_TM_ZONE': 1,
 'HAVE_SYMLINK': 1,
 'HAVE_SYMLINKAT': 1,
 'HAVE_SYNC': 1,
 'HAVE_SYSCONF': 1,
 'HAVE_SYSEXITS_H': 1,
 'HAVE_SYSLOG_H': 1,
 'HAVE_SYSTEM': 1,
 'HAVE_SYS_AUDIOIO_H': 0,
 'HAVE_SYS_AUXV_H': 0,
 'HAVE_SYS_BSDTTY_H': 0,
 'HAVE_SYS_DEVPOLL_H': 0,
 'HAVE_SYS_DIR_H': 0,
 'HAVE_SYS_ENDIAN_H': 0,
 'HAVE_SYS_EPOLL_H': 0,
 'HAVE_SYS_EVENTFD_H': 0,
 'HAVE_SYS_EVENT_H': 1,
 'HAVE_SYS_FILE_H': 1,
 'HAVE_SYS_IOCTL_H': 1,
 'HAVE_SYS_KERN_CONTROL_H': 1,
 'HAVE_SYS_LOADAVG_H': 0,
 'HAVE_SYS_LOCK_H': 1,
 'HAVE_SYS_MEMFD_H': 0,
 'HAVE_SYS_MKDEV_H': 0,
 'HAVE_SYS_MMAN_H': 1,
 'HAVE_SYS_MODEM_H': 0,
 'HAVE_SYS_NDIR_H': 0,
 'HAVE_SYS_PARAM_H': 1,
 'HAVE_SYS_POLL_H': 1,
 'HAVE_SYS_RANDOM_H': 1,
 'HAVE_SYS_RESOURCE_H': 1,
 'HAVE_SYS_SELECT_H': 1,
 'HAVE_SYS_SENDFILE_H': 0,
 'HAVE_SYS_SOCKET_H': 1,
 'HAVE_SYS_SOUNDCARD_H': 0,
 'HAVE_SYS_STATVFS_H': 1,
 'HAVE_SYS_STAT_H': 1,
 'HAVE_SYS_SYSCALL_H': 1,
 'HAVE_SYS_SYSMACROS_H': 0,
 'HAVE_SYS_SYS_DOMAIN_H': 1,
 'HAVE_SYS_TERMIO_H': 0,
 'HAVE_SYS_TIMES_H': 1,
 'HAVE_SYS_TIME_H': 1,
 'HAVE_SYS_TYPES_H': 1,
 'HAVE_SYS_UIO_H': 1,
 'HAVE_SYS_UN_H': 1,
 'HAVE_SYS_UTSNAME_H': 1,
 'HAVE_SYS_WAIT_H': 1,
 'HAVE_SYS_XATTR_H': 1,
 'HAVE_TCGETPGRP': 1,
 'HAVE_TCSETPGRP': 1,
 'HAVE_TEMPNAM': 1,
 'HAVE_TERMIOS_H': 1,
 'HAVE_TERM_H': 1,
 'HAVE_TIMEGM': 1,
 'HAVE_TIMES': 1,
 'HAVE_TMPFILE': 1,
 'HAVE_TMPNAM': 1,
 'HAVE_TMPNAM_R': 0,
 'HAVE_TM_ZONE': 1,
 'HAVE_TRUNCATE': 1,
 'HAVE_TTYNAME': 1,
 'HAVE_TZNAME': 0,
 'HAVE_UMASK': 1,
 'HAVE_UNAME': 1,
 'HAVE_UNISTD_H': 1,
 'HAVE_UNLINKAT': 1,
 'HAVE_USABLE_WCHAR_T': 0,
 'HAVE_UTIL_H': 1,
 'HAVE_UTIMENSAT': 1,
 'HAVE_UTIMES': 1,
 'HAVE_UTIME_H': 1,
 'HAVE_UTMP_H': 1,
 'HAVE_UUID_CREATE': 0,
 'HAVE_UUID_ENC_BE': 0,
 'HAVE_UUID_GENERATE_TIME_SAFE': 1,
 'HAVE_UUID_H': 1,
 'HAVE_UUID_UUID_H': 1,
 'HAVE_VFORK': 1,
 'HAVE_WAIT': 1,
 'HAVE_WAIT3': 1,
 'HAVE_WAIT4': 1,
 'HAVE_WAITID': 1,
 'HAVE_WAITPID': 1,
 'HAVE_WCHAR_H': 1,
 'HAVE_WCSCOLL': 1,
 'HAVE_WCSFTIME': 1,
 'HAVE_WCSXFRM': 1,
 'HAVE_WMEMCMP': 1,
 'HAVE_WORKING_TZSET': 1,
 'HAVE_WRITEV': 1,
 'HAVE_ZLIB_COPY': 1,
 'HAVE_ZLIB_H': 1,
 'HAVE__GETPTY': 0,
 'HOSTRUNNER': '',
 'HOST_GNU_TYPE': 'aarch64-apple-darwin',
 'INCLDIRSTOMAKE': '/install/include /install/include '
                   '/install/include/python3.11 /install/include/python3.11',
 'INCLUDEDIR': '/install/include',
 'INCLUDEPY': '/install/include/python3.11',
 'INSTALL': '/usr/bin/install -c',
 'INSTALL_DATA': '/usr/bin/install -c -m 644',
 'INSTALL_PROGRAM': '/usr/bin/install -c',
 'INSTALL_SCRIPT': '/usr/bin/install -c',
 'INSTALL_SHARED': '/usr/bin/install -c -m 755',
 'INSTSONAME': 'libpython3.11.dylib',
 'IO_H': 'Modules/_io/_iomodule.h',
 'IO_OBJS': '\\',
 'LDCXXSHARED': 'clang++ -bundle -undefined dynamic_lookup',
 'LDFLAGS': '-arch arm64 -mmacosx-version-min=11.0 -isysroot '
            '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
            '',
 'LDLIBRARY': 'libpython3.11.dylib',
 'LDLIBRARYDIR': '',
 'LDSHARED': 'clang -bundle -undefined dynamic_lookup -arch arm64 '
             '-mmacosx-version-min=11.0 -isysroot '
             '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
             '',
 'LDVERSION': '3.11',
 'LIBC': '',
 'LIBDEST': '/install/lib/python3.11',
 'LIBDIR': '/install/lib',
 'LIBEXPAT_A': 'Modules/expat/libexpat.a',
 'LIBEXPAT_CFLAGS': '-DNDEBUG -g -fwrapv -O3 -Wall -arch arm64 '
                    '-mmacosx-version-min=11.0 -Wno-nullability-completeness '
                    '-Wno-expansion-to-defined -Wno-undef-prefix  -isysroot '
                    '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                    '-fPIC '
                    ' '
                    ' '
                    ' '
                    '-Werror=unguarded-availability-new -flto -std=c11 '
                    '-Werror=implicit-function-declaration -fvisibility=hidden '
                    '-fprofile-instr-use=code.profclangd -I./Include/internal '
                    '-I. -I./Include -arch arm64 -mmacosx-version-min=11.0 '
                    '-Wno-nullability-completeness -Wno-expansion-to-defined '
                    '-Wno-undef-prefix  -isysroot '
                    '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                    '-fPIC '
                    ' '
                    ' '
                    ' '
                    '-Werror=unguarded-availability-new',
 'LIBEXPAT_HEADERS': '\\',
 'LIBEXPAT_OBJS': '\\',
 'LIBFFI_INCLUDEDIR': '',
 'LIBM': '',
 'LIBMPDEC_A': 'Modules/_decimal/libmpdec/libmpdec.a',
 'LIBMPDEC_CFLAGS': '-DUNIVERSAL=1 -DNDEBUG -g -fwrapv -O3 -Wall -arch arm64 '
                    '-mmacosx-version-min=11.0 -Wno-nullability-completeness '
                    '-Wno-expansion-to-defined -Wno-undef-prefix  -isysroot '
                    '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                    '-fPIC '
                    ' '
                    ' '
                    ' '
                    '-Werror=unguarded-availability-new -flto -std=c11 '
                    '-Werror=implicit-function-declaration -fvisibility=hidden '
                    '-fprofile-instr-use=code.profclangd -I./Include/internal '
                    '-I. -I./Include -arch arm64 -mmacosx-version-min=11.0 '
                    '-Wno-nullability-completeness -Wno-expansion-to-defined '
                    '-Wno-undef-prefix  -isysroot '
                    '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                    '-fPIC '
                    ' '
                    ' '
                    ' '
                    '-Werror=unguarded-availability-new',
 'LIBMPDEC_HEADERS': '\\',
 'LIBMPDEC_OBJS': '\\',
 'LIBOBJDIR': 'Python/',
 'LIBOBJS': '',
 'LIBPC': '/install/lib/pkgconfig',
 'LIBPL': '/install/lib/python3.11/config-3.11-darwin',
 'LIBPYTHON': '',
 'LIBRARY': 'libpython3.11.a',
 'LIBRARY_DEPS': 'libpython3.11.a libpython3.11.dylib',
 'LIBRARY_OBJS': '\\',
 'LIBRARY_OBJS_OMIT_FROZEN': '\\',
 'LIBS': '-ldl  -framework CoreFoundation',
 'LIBSUBDIRS': 'asyncio \\',
 'LINKCC': 'clang',
 'LINKFORSHARED': '-Wl,-stack_size,1000000  -framework CoreFoundation',
 'LINK_PYTHON_DEPS': 'libpython3.11.a libpython3.11.dylib',
 'LINK_PYTHON_OBJS': '-L. -lpython3.11',
 'LIPO_32BIT_FLAGS': '',
 'LIPO_INTEL64_FLAGS': '',
 'LLVM_PROF_ERR': 'no',
 'LLVM_PROF_FILE': 'LLVM_PROFILE_FILE="code-%p.profclangr"',
 'LLVM_PROF_MERGER': '/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/tools/llvm/bin/llvm-profdata '
                     'merge -output=code.profclangd *.profclangr',
 'LN': 'ln',
 'LOCALMODLIBS': '-Xlinker -hidden-lbz2          -Xlinker -hidden-lffi '
                 '-Xlinker -hidden-ldl  -Xlinker -hidden-lm  -Xlinker '
                 '-hidden-lncurses  -Xlinker -hidden-lpanel -Xlinker '
                 '-hidden-lncurses    -Xlinker -hidden-lmpdec  -Xlinker '
                 '-hidden-lexpat  -Xlinker -hidden-lcrypto     -Xlinker '
                 '-hidden-llzma           -framework CoreFoundation -framework '
                 'SystemConfiguration       -Xlinker -hidden-lsqlite3  '
                 '-Xlinker -hidden-lssl -Xlinker -hidden-lcrypto        '
                 '-Xlinker -hidden-ltcl8.6 -Xlinker -hidden-ltk8.6 -framework '
                 'AppKit -framework ApplicationServices -framework Carbon '
                 '-framework Cocoa -framework CoreFoundation -framework '
                 'CoreServices -framework CoreGraphics -framework IOKit '
                 '-framework QuartzCore -Xlinker -ObjC   -Xlinker '
                 '-hidden-luuid        -Xlinker -hidden-lm    -Xlinker '
                 '-hidden-lm   -Xlinker -hidden-lexpat  -Xlinker -hidden-ledit '
                 '-Xlinker -hidden-lncurses        -Xlinker -hidden-lz',
 'MACHDEP': 'darwin',
 'MACHDEP_OBJS': '',
 'MACHDESTLIB': '/install/lib/python3.11',
 'MACOSX_DEPLOYMENT_TARGET': '11.0',
 'MAINCC': 'clang',
 'MAJOR_IN_MKDEV': 0,
 'MAJOR_IN_SYSMACROS': 0,
 'MAKESETUP': './Modules/makesetup',
 'MANDIR': '/install/share/man',
 'MKDIR_P': './install-sh -c -d',
 'MODBUILT_NAMES': '_crypt  _asyncio  _bisect  _blake2  _bz2  _codecs_cn  '
                   '_codecs_hk  _codecs_iso2022  _codecs_jp  _codecs_kr  '
                   '_codecs_tw  _contextvars  _csv  _ctypes  _ctypes_test  '
                   '_curses  _curses_panel  _datetime  _dbm  _decimal  '
                   '_elementtree  _hashlib  _heapq  _json  _lsprof  _lzma  '
                   '_md5  _multibytecodec  _multiprocessing  _opcode  _pickle  '
                   '_posixshmem  _posixsubprocess  _queue  _random  _scproxy  '
                   '_sha1  _sha256  _sha3  _sha512  _socket  _sqlite3  _ssl  '
                   '_statistics  _struct  _testbuffer  _testimportmultiple  '
                   '_testinternalcapi  _testmultiphase  _tkinter  _typing  '
                   '_uuid  _xxsubinterpreters  _xxtestfuzz  _zoneinfo  array  '
                   'audioop  binascii  cmath  fcntl  grp  math  mmap  pyexpat  '
                   'readline  resource  select  syslog  termios  unicodedata  '
                   'xxsubtype  zlib  atexit  faulthandler  posix  _signal  '
                   '_tracemalloc  _codecs  _collections  errno  _io  '
                   'itertools  _sre  _thread  time  _weakref  _abc  '
                   '_functools  _locale  _operator  _stat  _symtable  pwd',
 'MODDISABLED_NAMES': '_gdbm  _testcapi  nis  ossaudiodev  spwd  xx  '
                      'xxlimited  xxlimited_35',
 'MODLIBS': '-Xlinker -hidden-lbz2          -Xlinker -hidden-lffi -Xlinker '
            '-hidden-ldl  -Xlinker -hidden-lm  -Xlinker -hidden-lncurses  '
            '-Xlinker -hidden-lpanel -Xlinker -hidden-lncurses    -Xlinker '
            '-hidden-lmpdec  -Xlinker -hidden-lexpat  -Xlinker '
            '-hidden-lcrypto     -Xlinker -hidden-llzma           -framework '
            'CoreFoundation -framework SystemConfiguration       -Xlinker '
            '-hidden-lsqlite3  -Xlinker -hidden-lssl -Xlinker '
            '-hidden-lcrypto        -Xlinker -hidden-ltcl8.6 -Xlinker '
            '-hidden-ltk8.6 -framework AppKit -framework ApplicationServices '
            '-framework Carbon -framework Cocoa -framework CoreFoundation '
            '-framework CoreServices -framework CoreGraphics -framework IOKit '
            '-framework QuartzCore -Xlinker -ObjC   -Xlinker '
            '-hidden-luuid        -Xlinker -hidden-lm    -Xlinker -hidden-lm   '
            '-Xlinker -hidden-lexpat  -Xlinker -hidden-ledit -Xlinker '
            '-hidden-lncurses        -Xlinker -hidden-lz',
 'MODOBJS': 'Modules/_asynciomodule.o  Modules/_bisectmodule.o  '
            'Modules/_blake2/blake2module.o Modules/_blake2/blake2b_impl.o '
            'Modules/_blake2/blake2s_impl.o  Modules/_bz2module.o  '
            'Modules/cjkcodecs/_codecs_cn.o  Modules/cjkcodecs/_codecs_hk.o  '
            'Modules/cjkcodecs/_codecs_iso2022.o  '
            'Modules/cjkcodecs/_codecs_jp.o  Modules/cjkcodecs/_codecs_kr.o  '
            'Modules/cjkcodecs/_codecs_tw.o  Modules/_contextvarsmodule.o  '
            'Modules/_csv.o  Modules/_ctypes/_ctypes.o '
            'Modules/_ctypes/callbacks.o Modules/_ctypes/callproc.o '
            'Modules/_ctypes/stgdict.o Modules/_ctypes/cfield.o '
            'Modules/_ctypes/darwin/dlfcn_simple.o '
            'Modules/_ctypes/malloc_closure.o  Modules/_ctypes/_ctypes_test.o  '
            'Modules/_cursesmodule.o  Modules/_curses_panel.o  '
            'Modules/_datetimemodule.o  Modules/_dbmmodule.o  '
            'Modules/_decimal/_decimal.o  Modules/_elementtree.o  '
            'Modules/_hashopenssl.o  Modules/_heapqmodule.o  Modules/_json.o  '
            'Modules/_lsprof.o Modules/rotatingtree.o  Modules/_lzmamodule.o  '
            'Modules/md5module.o  Modules/cjkcodecs/multibytecodec.o  '
            'Modules/_multiprocessing/multiprocessing.o '
            'Modules/_multiprocessing/semaphore.o  Modules/_opcode.o  '
            'Modules/_pickle.o  Modules/_multiprocessing/posixshmem.o  '
            'Modules/_posixsubprocess.o  Modules/_queuemodule.o  '
            'Modules/_randommodule.o  Modules/_scproxy.o  '
            'Modules/sha1module.o  Modules/sha256module.o  '
            'Modules/_sha3/sha3module.o  Modules/sha512module.o  '
            'Modules/socketmodule.o  Modules/_sqlite/connection.o '
            'Modules/_sqlite/cursor.o Modules/_sqlite/microprotocols.o '
            'Modules/_sqlite/module.o Modules/_sqlite/prepare_protocol.o '
            'Modules/_sqlite/row.o Modules/_sqlite/statement.o '
            'Modules/_sqlite/util.o Modules/_sqlite/blob.o  Modules/_ssl.o  '
            'Modules/_statisticsmodule.o  Modules/_struct.o  '
            'Modules/_testbuffer.o  Modules/_testimportmultiple.o  '
            'Modules/_testinternalcapi.o  Modules/_testmultiphase.o  '
            'Modules/_tkinter.o Modules/tkappinit.o  Modules/_typingmodule.o  '
            'Modules/_uuidmodule.o  Modules/_xxsubinterpretersmodule.o  '
            'Modules/_xxtestfuzz/_xxtestfuzz.o Modules/_xxtestfuzz/fuzzer.o  '
            'Modules/_zoneinfo.o  Modules/arraymodule.o  Modules/audioop.o  '
            'Modules/binascii.o  Modules/cmathmodule.o  Modules/fcntlmodule.o  '
            'Modules/grpmodule.o  Modules/mathmodule.o  Modules/mmapmodule.o  '
            'Modules/pyexpat.o  Modules/readline.o  Modules/resource.o  '
            'Modules/selectmodule.o  Modules/syslogmodule.o  '
            'Modules/termios.o  Modules/unicodedata.o  Modules/xxsubtype.o  '
            'Modules/zlibmodule.o  Modules/atexitmodule.o  '
            'Modules/faulthandler.o  Modules/posixmodule.o  '
            'Modules/signalmodule.o  Modules/_tracemalloc.o  '
            'Modules/_codecsmodule.o  Modules/_collectionsmodule.o  '
            'Modules/errnomodule.o  Modules/_io/_iomodule.o '
            'Modules/_io/iobase.o Modules/_io/fileio.o Modules/_io/bytesio.o '
            'Modules/_io/bufferedio.o Modules/_io/textio.o '
            'Modules/_io/stringio.o  Modules/itertoolsmodule.o  '
            'Modules/_sre/sre.o  Modules/_threadmodule.o  '
            'Modules/timemodule.o  Modules/_weakref.o  Modules/_abc.o  '
            'Modules/_functoolsmodule.o  Modules/_localemodule.o  '
            'Modules/_operator.o  Modules/_stat.o  Modules/symtablemodule.o  '
            'Modules/pwdmodule.o',
 'MODSHARED_NAMES': '_crypt',
 'MODULE_ARRAY_LDFLAGS': '',
 'MODULE_ARRAY_STATE': '',
 'MODULE_ATEXIT_LDFLAGS': '',
 'MODULE_AUDIOOP_LDFLAGS': '',
 'MODULE_AUDIOOP_STATE': '',
 'MODULE_BINASCII_LDFLAGS': '',
 'MODULE_BINASCII_STATE': '',
 'MODULE_CMATH_DEPS': './Modules/_math.h',
 'MODULE_CMATH_STATE': '',
 'MODULE_ERRNO_LDFLAGS': '',
 'MODULE_FAULTHANDLER_LDFLAGS': '',
 'MODULE_FCNTL_LDFLAGS': '',
 'MODULE_FCNTL_STATE': '',
 'MODULE_GRP_LDFLAGS': '',
 'MODULE_GRP_STATE': '',
 'MODULE_ITERTOOLS_LDFLAGS': '',
 'MODULE_MATH_DEPS': './Modules/_math.h',
 'MODULE_MATH_STATE': '',
 'MODULE_MMAP_LDFLAGS': '',
 'MODULE_MMAP_STATE': '',
 'MODULE_NIS_STATE': '',
 'MODULE_OBJS': '\\',
 'MODULE_OSSAUDIODEV_STATE': '',
 'MODULE_POSIX_LDFLAGS': '',
 'MODULE_PWD_LDFLAGS': '',
 'MODULE_PWD_STATE': '',
 'MODULE_PYEXPAT_DEPS': '',
 'MODULE_PYEXPAT_STATE': '',
 'MODULE_RESOURCE_LDFLAGS': '',
 'MODULE_RESOURCE_STATE': '',
 'MODULE_SELECT_LDFLAGS': '',
 'MODULE_SELECT_STATE': '',
 'MODULE_SPWD_STATE': '',
 'MODULE_SYSLOG_LDFLAGS': '',
 'MODULE_SYSLOG_STATE': '',
 'MODULE_TERMIOS_LDFLAGS': '',
 'MODULE_TERMIOS_STATE': '',
 'MODULE_TIME_LDFLAGS': '',
 'MODULE_TIME_STATE': '',
 'MODULE_UNICODEDATA_DEPS': './Modules/unicodedata_db.h '
                            './Modules/unicodename_db.h',
 'MODULE_UNICODEDATA_LDFLAGS': '',
 'MODULE_UNICODEDATA_STATE': '',
 'MODULE_XXLIMITED_35_STATE': '',
 'MODULE_XXLIMITED_STATE': '',
 'MODULE_XXSUBTYPE_LDFLAGS': '',
 'MODULE_ZLIB_STATE': '',
 'MODULE__ABC_LDFLAGS': '',
 'MODULE__ASYNCIO_LDFLAGS': '',
 'MODULE__ASYNCIO_STATE': '',
 'MODULE__BISECT_LDFLAGS': '',
 'MODULE__BISECT_STATE': '',
 'MODULE__BLAKE2_DEPS': './Modules/_blake2/impl/blake2-config.h '
                        './Modules/_blake2/impl/blake2-impl.h '
                        './Modules/_blake2/impl/blake2.h '
                        './Modules/_blake2/impl/blake2b-load-sse2.h '
                        './Modules/_blake2/impl/blake2b-load-sse41.h '
                        './Modules/_blake2/impl/blake2b-ref.c '
                        './Modules/_blake2/impl/blake2b-round.h '
                        './Modules/_blake2/impl/blake2b.c '
                        './Modules/_blake2/impl/blake2s-load-sse2.h '
                        './Modules/_blake2/impl/blake2s-load-sse41.h '
                        './Modules/_blake2/impl/blake2s-load-xop.h '
                        './Modules/_blake2/impl/blake2s-ref.c '
                        './Modules/_blake2/impl/blake2s-round.h '
                        './Modules/_blake2/impl/blake2s.c '
                        './Modules/_blake2/blake2module.h ./Modules/hashlib.h',
 'MODULE__BLAKE2_LDFLAGS': '',
 'MODULE__BLAKE2_STATE': '',
 'MODULE__BZ2_STATE': '',
 'MODULE__CODECS_CN_LDFLAGS': '',
 'MODULE__CODECS_CN_STATE': '',
 'MODULE__CODECS_HK_LDFLAGS': '',
 'MODULE__CODECS_HK_STATE': '',
 'MODULE__CODECS_ISO2022_LDFLAGS': '',
 'MODULE__CODECS_ISO2022_STATE': '',
 'MODULE__CODECS_JP_LDFLAGS': '',
 'MODULE__CODECS_JP_STATE': '',
 'MODULE__CODECS_KR_LDFLAGS': '',
 'MODULE__CODECS_KR_STATE': '',
 'MODULE__CODECS_LDFLAGS': '',
 'MODULE__CODECS_TW_LDFLAGS': '',
 'MODULE__CODECS_TW_STATE': '',
 'MODULE__COLLECTIONS_LDFLAGS': '',
 'MODULE__CONTEXTVARS_LDFLAGS': '',
 'MODULE__CONTEXTVARS_STATE': '',
 'MODULE__CRYPT_STATE': '',
 'MODULE__CSV_LDFLAGS': '',
 'MODULE__CSV_STATE': '',
 'MODULE__CTYPES_DEPS': './Modules/_ctypes/ctypes.h',
 'MODULE__CTYPES_TEST_STATE': '',
 'MODULE__DATETIME_LDFLAGS': '',
 'MODULE__DATETIME_STATE': '',
 'MODULE__DECIMAL_DEPS': './Modules/_decimal/docstrings.h',
 'MODULE__DECIMAL_STATE': '',
 'MODULE__ELEMENTTREE_DEPS': './Modules/pyexpat.c',
 'MODULE__ELEMENTTREE_STATE': '',
 'MODULE__FUNCTOOLS_LDFLAGS': '',
 'MODULE__GDBM_STATE': '',
 'MODULE__HASHLIB_DEPS': './Modules/hashlib.h',
 'MODULE__HASHLIB_STATE': '',
 'MODULE__HEAPQ_LDFLAGS': '',
 'MODULE__HEAPQ_STATE': '',
 'MODULE__IO_DEPS': './Modules/_io/_iomodule.h',
 'MODULE__IO_LDFLAGS': '',
 'MODULE__IO_STATE': '',
 'MODULE__JSON_LDFLAGS': '',
 'MODULE__JSON_STATE': '',
 'MODULE__LOCALE_LDFLAGS': '',
 'MODULE__LSPROF_LDFLAGS': '',
 'MODULE__LSPROF_STATE': '',
 'MODULE__LZMA_STATE': '',
 'MODULE__MD5_DEPS': './Modules/hashlib.h',
 'MODULE__MD5_STATE': '',
 'MODULE__MULTIBYTECODEC_LDFLAGS': '',
 'MODULE__MULTIBYTECODEC_STATE': '',
 'MODULE__MULTIPROCESSING_LDFLAGS': '',
 'MODULE__MULTIPROCESSING_STATE': '',
 'MODULE__OPCODE_LDFLAGS': '',
 'MODULE__OPCODE_STATE': '',
 'MODULE__OPERATOR_LDFLAGS': '',
 'MODULE__PICKLE_LDFLAGS': '',
 'MODULE__PICKLE_STATE': '',
 'MODULE__POSIXSHMEM_STATE': '',
 'MODULE__POSIXSUBPROCESS_LDFLAGS': '',
 'MODULE__POSIXSUBPROCESS_STATE': '',
 'MODULE__QUEUE_LDFLAGS': '',
 'MODULE__QUEUE_STATE': '',
 'MODULE__RANDOM_LDFLAGS': '',
 'MODULE__RANDOM_STATE': '',
 'MODULE__SCPROXY_STATE': '',
 'MODULE__SHA1_DEPS': './Modules/hashlib.h',
 'MODULE__SHA1_STATE': '',
 'MODULE__SHA256_DEPS': './Modules/hashlib.h',
 'MODULE__SHA256_LDFLAGS': '',
 'MODULE__SHA256_STATE': '',
 'MODULE__SHA3_DEPS': './Modules/_sha3/sha3.c ./Modules/_sha3/sha3.h '
                      './Modules/hashlib.h',
 'MODULE__SHA3_STATE': '',
 'MODULE__SHA512_DEPS': './Modules/hashlib.h',
 'MODULE__SHA512_LDFLAGS': '',
 'MODULE__SHA512_STATE': '',
 'MODULE__SIGNAL_LDFLAGS': '',
 'MODULE__SOCKET_DEPS': './Modules/socketmodule.h ./Modules/addrinfo.h '
                        './Modules/getaddrinfo.c ./Modules/getnameinfo.c',
 'MODULE__SOCKET_LDFLAGS': '',
 'MODULE__SOCKET_STATE': '',
 'MODULE__SQLITE3_DEPS': './Modules/_sqlite/connection.h '
                         './Modules/_sqlite/cursor.h '
                         './Modules/_sqlite/microprotocols.h '
                         './Modules/_sqlite/module.h '
                         './Modules/_sqlite/prepare_protocol.h '
                         './Modules/_sqlite/row.h ./Modules/_sqlite/util.h',
 'MODULE__SQLITE3_STATE': '',
 'MODULE__SRE_LDFLAGS': '',
 'MODULE__SSL_DEPS': './Modules/_ssl.h ./Modules/_ssl/cert.c '
                     './Modules/_ssl/debughelpers.c ./Modules/_ssl/misc.c '
                     './Modules/_ssl_data.h ./Modules/_ssl_data_111.h '
                     './Modules/_ssl_data_300.h ./Modules/socketmodule.h',
 'MODULE__SSL_STATE': '',
 'MODULE__STATISTICS_LDFLAGS': '',
 'MODULE__STATISTICS_STATE': '',
 'MODULE__STAT_LDFLAGS': '',
 'MODULE__STRUCT_LDFLAGS': '',
 'MODULE__STRUCT_STATE': '',
 'MODULE__SYMTABLE_LDFLAGS': '',
 'MODULE__TESTBUFFER_LDFLAGS': '',
 'MODULE__TESTBUFFER_STATE': '',
 'MODULE__TESTCAPI_DEPS': './Modules/testcapi_long.h',
 'MODULE__TESTCAPI_STATE': '',
 'MODULE__TESTCLINIC_STATE': '',
 'MODULE__TESTIMPORTMULTIPLE_LDFLAGS': '',
 'MODULE__TESTIMPORTMULTIPLE_STATE': '',
 'MODULE__TESTINTERNALCAPI_STATE': '',
 'MODULE__TESTMULTIPHASE_LDFLAGS': '',
 'MODULE__TESTMULTIPHASE_STATE': '',
 'MODULE__THREAD_LDFLAGS': '',
 'MODULE__TKINTER_STATE': '',
 'MODULE__TRACEMALLOC_LDFLAGS': '',
 'MODULE__TYPING_LDFLAGS': '',
 'MODULE__TYPING_STATE': '',
 'MODULE__UUID_STATE': '',
 'MODULE__WEAKREF_LDFLAGS': '',
 'MODULE__XXSUBINTERPRETERS_LDFLAGS': '',
 'MODULE__XXSUBINTERPRETERS_STATE': '',
 'MODULE__XXTESTFUZZ_LDFLAGS': '',
 'MODULE__XXTESTFUZZ_STATE': '',
 'MODULE__ZONEINFO_LDFLAGS': '',
 'MODULE__ZONEINFO_STATE': '',
 'MULTIARCH': 'darwin',
 'MULTIARCH_CPPFLAGS': '-DMULTIARCH=\\"darwin\\"',
 'MVWDELCH_IS_EXPRESSION': 1,
 'NO_AS_NEEDED': '-Wl,--no-as-needed',
 'OBJECT_OBJS': '\\',
 'OPENSSL_INCLUDES': '',
 'OPENSSL_LDFLAGS': '',
 'OPENSSL_LIBS': '-lssl -lcrypto',
 'OPENSSL_RPATH': '',
 'OPT': '-DNDEBUG -g -fwrapv -O3 -Wall',
 'OTHER_LIBTOOL_OPT': '',
 'PACKAGE_BUGREPORT': 0,
 'PACKAGE_NAME': 0,
 'PACKAGE_STRING': 0,
 'PACKAGE_TARNAME': 0,
 'PACKAGE_URL': 0,
 'PACKAGE_VERSION': 0,
 'PARSER_HEADERS': '\\',
 'PARSER_OBJS': '\\ \\ Parser/myreadline.o Parser/tokenizer.o',
 'PEGEN_HEADERS': '\\',
 'PEGEN_OBJS': '\\',
 'PGO_PROF_GEN_FLAG': '-fprofile-instr-generate',
 'PGO_PROF_USE_FLAG': '-fprofile-instr-use=code.profclangd',
 'PLATLIBDIR': 'lib',
 'POBJS': '\\',
 'POSIX_SEMAPHORES_NOT_ENABLED': 0,
 'PROFILE_TASK': '-m test --pgo --timeout=1200',
 'PTHREAD_KEY_T_IS_COMPATIBLE_WITH_INT': 0,
 'PTHREAD_SYSTEM_SCHED_SUPPORTED': 1,
 'PURIFY': '',
 'PY3LIBRARY': '',
 'PYLONG_BITS_IN_DIGIT': 0,
 'PYTHON': 'python',
 'PYTHONFRAMEWORK': '',
 'PYTHONFRAMEWORKDIR': 'no-framework',
 'PYTHONFRAMEWORKINSTALLDIR': '',
 'PYTHONFRAMEWORKPREFIX': '',
 'PYTHONPATH': '',
 'PYTHON_FOR_BUILD': '_PYTHON_PROJECT_BASE=/private/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/Python-3.11.10 '
                     '_PYTHON_HOST_PLATFORM=$(_PYTHON_HOST_PLATFORM) '
                     'PYTHONPATH=$(shell test -f pybuilddir.txt && echo '
                     '/private/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/Python-3.11.10/`cat '
                     'pybuilddir.txt`:)./Lib '
                     '_PYTHON_SYSCONFIGDATA_NAME=_sysconfigdata__darwin_darwin '
                     '/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/tools/host/bin/python3.11',
 'PYTHON_FOR_BUILD_DEPS': '',
 'PYTHON_FOR_FREEZE': '/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/tools/host/bin/python3.11',
 'PYTHON_FOR_REGEN': '',
 'PYTHON_HEADERS': '\\',
 'PYTHON_OBJS': '\\',
 'PY_BUILTIN_HASHLIB_HASHES': '"md5,sha1,sha256,sha512,sha3,blake2"',
 'PY_BUILTIN_MODULE_CFLAGS': '-DNDEBUG -g -fwrapv -O3 -Wall -arch arm64 '
                             '-mmacosx-version-min=11.0 '
                             '-Wno-nullability-completeness '
                             '-Wno-expansion-to-defined -Wno-undef-prefix  '
                             '-isysroot '
                             '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                             '-fPIC '
                             ' '
                             ' '
                             ' '
                             '-Werror=unguarded-availability-new -flto '
                             '-std=c11 -Werror=implicit-function-declaration '
                             '-fvisibility=hidden '
                             '-fprofile-instr-use=code.profclangd '
                             '-I./Include/internal -I. -I./Include -arch arm64 '
                             '-mmacosx-version-min=11.0 '
                             '-Wno-nullability-completeness '
                             '-Wno-expansion-to-defined -Wno-undef-prefix  '
                             '-isysroot '
                             '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                             '-fPIC '
                             ' '
                             ' '
                             ' '
                             '-Werror=unguarded-availability-new '
                             '-DPy_BUILD_CORE_BUILTIN',
 'PY_CFLAGS': '-DNDEBUG -g -fwrapv -O3 -Wall -arch arm64 '
              '-mmacosx-version-min=11.0 -Wno-nullability-completeness '
              '-Wno-expansion-to-defined -Wno-undef-prefix  -isysroot '
              '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
              '-fPIC '
              ' '
              ' '
              ' '
              '-Werror=unguarded-availability-new',
 'PY_CFLAGS_NODIST': '-flto -std=c11 -Werror=implicit-function-declaration '
                     '-fvisibility=hidden -fprofile-instr-use=code.profclangd '
                     '-I./Include/internal',
 'PY_COERCE_C_LOCALE': 1,
 'PY_CORE_CFLAGS': '-DNDEBUG -g -fwrapv -O3 -Wall -arch arm64 '
                   '-mmacosx-version-min=11.0 -Wno-nullability-completeness '
                   '-Wno-expansion-to-defined -Wno-undef-prefix  -isysroot '
                   '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                   '-fPIC '
                   ' '
                   ' '
                   ' '
                   '-Werror=unguarded-availability-new -flto -std=c11 '
                   '-Werror=implicit-function-declaration -fvisibility=hidden '
                   '-fprofile-instr-use=code.profclangd -I./Include/internal '
                   '-I. -I./Include -arch arm64 -mmacosx-version-min=11.0 '
                   '-Wno-nullability-completeness -Wno-expansion-to-defined '
                   '-Wno-undef-prefix  -isysroot '
                   '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                   '-fPIC '
                   ' '
                   ' '
                   ' '
                   '-Werror=unguarded-availability-new -DPy_BUILD_CORE',
 'PY_CORE_LDFLAGS': '-arch arm64 -mmacosx-version-min=11.0 -isysroot '
                    '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                    ' '
                    '-flto -Wl,-export_dynamic -g',
 'PY_CPPFLAGS': '-I. -I./Include -arch arm64 -mmacosx-version-min=11.0 '
                '-Wno-nullability-completeness -Wno-expansion-to-defined '
                '-Wno-undef-prefix  -isysroot '
                '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                '-fPIC '
                ' '
                ' '
                ' '
                '-Werror=unguarded-availability-new',
 'PY_ENABLE_SHARED': 1,
 'PY_FORMAT_SIZE_T': '"z"',
 'PY_LDFLAGS': '-arch arm64 -mmacosx-version-min=11.0 -isysroot '
               '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
               '',
 'PY_LDFLAGS_NODIST': '-flto -Wl,-export_dynamic -g',
 'PY_LDFLAGS_NOLTO': '-arch arm64 -mmacosx-version-min=11.0 -isysroot '
                     '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                     ' '
                     '-flto=thin',
 'PY_SQLITE_ENABLE_LOAD_EXTENSION': 0,
 'PY_SQLITE_HAVE_SERIALIZE': 1,
 'PY_SSL_DEFAULT_CIPHERS': 1,
 'PY_SSL_DEFAULT_CIPHER_STRING': 0,
 'PY_STDMODULE_CFLAGS': '-DNDEBUG -g -fwrapv -O3 -Wall -arch arm64 '
                        '-mmacosx-version-min=11.0 '
                        '-Wno-nullability-completeness '
                        '-Wno-expansion-to-defined -Wno-undef-prefix  '
                        '-isysroot '
                        '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                        '-fPIC '
                        ' '
                        ' '
                        ' '
                        '-Werror=unguarded-availability-new -flto -std=c11 '
                        '-Werror=implicit-function-declaration '
                        '-fvisibility=hidden '
                        '-fprofile-instr-use=code.profclangd '
                        '-I./Include/internal -I. -I./Include -arch arm64 '
                        '-mmacosx-version-min=11.0 '
                        '-Wno-nullability-completeness '
                        '-Wno-expansion-to-defined -Wno-undef-prefix  '
                        '-isysroot '
                        '/Applications/Xcode_15.2.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX14.2.sdk '
                        '-fPIC '
                        ' '
                        ' '
                        ' '
                        '-Werror=unguarded-availability-new',
 'PY_SUPPORT_TIER': 2,
 'Py_DEBUG': 0,
 'Py_ENABLE_SHARED': 1,
 'Py_HASH_ALGORITHM': 0,
 'Py_STATS': 0,
 'Py_SUNOS_VERSION': 0,
 'Py_TRACE_REFS': 0,
 'QUICKTESTOPTS': '-x test_subprocess test_io test_lib2to3 \\',
 'READELF': ':',
 'RESSRCDIR': 'Mac/Resources/framework',
 'RETSIGTYPE': 'void',
 'RUNSHARED': 'DYLD_LIBRARY_PATH=/private/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/Python-3.11.10',
 'SCRIPTDIR': '/install/lib',
 'SETPGRP_HAVE_ARG': 0,
 'SHAREDMODS': 'Modules/_crypt.cpython-311-darwin.so',
 'SHELL': '/bin/sh',
 'SHLIBS': '-ldl  -framework CoreFoundation',
 'SHLIB_SUFFIX': '.so',
 'SIGNED_RIGHT_SHIFT_ZERO_FILLS': 0,
 'SITEPATH': '',
 'SIZEOF_DOUBLE': 8,
 'SIZEOF_FLOAT': 4,
 'SIZEOF_FPOS_T': 8,
 'SIZEOF_INT': 4,
 'SIZEOF_LONG': 8,
 'SIZEOF_LONG_DOUBLE': 8,
 'SIZEOF_LONG_LONG': 8,
 'SIZEOF_OFF_T': 8,
 'SIZEOF_PID_T': 4,
 'SIZEOF_PTHREAD_KEY_T': 8,
 'SIZEOF_PTHREAD_T': 8,
 'SIZEOF_SHORT': 2,
 'SIZEOF_SIZE_T': 8,
 'SIZEOF_TIME_T': 8,
 'SIZEOF_UINTPTR_T': 8,
 'SIZEOF_VOID_P': 8,
 'SIZEOF_WCHAR_T': 4,
 'SIZEOF__BOOL': 1,
 'SOABI': 'cpython-311-darwin',
 'SRCDIRS': 'Modules   Modules/_blake2   Modules/_ctypes   Modules/_decimal   '
            'Modules/_decimal/libmpdec   Modules/_io   '
            'Modules/_multiprocessing   Modules/_sha3   Modules/_sqlite   '
            'Modules/_sre   Modules/_xxtestfuzz   Modules/cjkcodecs   '
            'Modules/expat   Objects   Parser   Programs   Python   '
            'Python/frozen_modules   Python/deepfreeze',
 'SRC_GDB_HOOKS': './Tools/gdb/libpython.py',
 'STATIC_LIBPYTHON': 1,
 'STDC_HEADERS': 1,
 'STRICT_SYSV_CURSES': "/* Don't use ncurses extensions */",
 'STRIPFLAG': '-s',
 'SUBDIRS': '',
 'SUBDIRSTOO': 'Include Lib Misc',
 'SYSLIBS': '',
 'SYS_SELECT_WITH_SYS_TIME': 1,
 'TESTOPTS': '',
 'TESTPATH': '',
 'TESTPYTHON': 'DYLD_LIBRARY_PATH=/private/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/Python-3.11.10 '
               '_PYTHON_PROJECT_BASE=/private/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/Python-3.11.10 '
               '_PYTHON_HOST_PLATFORM=$(_PYTHON_HOST_PLATFORM) '
               'PYTHONPATH=$(shell test -f pybuilddir.txt && echo '
               '/private/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/Python-3.11.10/`cat '
               'pybuilddir.txt`:)./Lib '
               '_PYTHON_SYSCONFIGDATA_NAME=_sysconfigdata__darwin_darwin '
               '/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/tools/host/bin/python3.11',
 'TESTPYTHONOPTS': '',
 'TESTRUNNER': 'DYLD_LIBRARY_PATH=/private/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/Python-3.11.10 '
               '_PYTHON_PROJECT_BASE=/private/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/Python-3.11.10 '
               '_PYTHON_HOST_PLATFORM=$(_PYTHON_HOST_PLATFORM) '
               'PYTHONPATH=$(shell test -f pybuilddir.txt && echo '
               '/private/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/Python-3.11.10/`cat '
               'pybuilddir.txt`:)./Lib '
               '_PYTHON_SYSCONFIGDATA_NAME=_sysconfigdata__darwin_darwin '
               '/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/tools/host/bin/python3.11 '
               './Tools/scripts/run_tests.py',
 'TESTSUBDIRS': 'ctypes/test \\',
 'TESTTIMEOUT': 1200,
 'TEST_MODULES': 'yes',
 'THREAD_STACK_SIZE': '0x1000000',
 'TIMEMODULE_LIB': 0,
 'TIME_WITH_SYS_TIME': 1,
 'TM_IN_SYS_TIME': 0,
 'TZPATH': '/usr/share/zoneinfo:/usr/lib/zoneinfo:/usr/share/lib/zoneinfo:/etc/zoneinfo',
 'UNICODE_DEPS': '\\',
 'UNIVERSALSDK': '',
 'UPDATE_FILE': './Tools/scripts/update_file.py',
 'USE_COMPUTED_GOTOS': 0,
 'VERSION': '3.11',
 'WASM_ASSETS_DIR': './install',
 'WASM_STDLIB': './install/lib/python3.11/os.py',
 'WHEEL_PKG_DIR': '',
 'WINDOW_HAS_FLAGS': 1,
 'WITH_DECIMAL_CONTEXTVAR': 1,
 'WITH_DOC_STRINGS': 1,
 'WITH_DTRACE': 0,
 'WITH_DYLD': 1,
 'WITH_EDITLINE': 0,
 'WITH_FREELISTS': 1,
 'WITH_LIBINTL': 0,
 'WITH_NEXT_FRAMEWORK': 0,
 'WITH_PYMALLOC': 1,
 'WITH_VALGRIND': 0,
 'X87_DOUBLE_ROUNDING': 0,
 'XMLLIBSUBDIRS': 'xml xml/dom xml/etree xml/parsers xml/sax',
 'abs_builddir': '/private/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/Python-3.11.10',
 'abs_srcdir': '/private/var/folders/t_/mmhnh941511_hp2lwh383bp00000gn/T/tmp56_ouxxt/Python-3.11.10',
 'datarootdir': '/install/share',
 'exec_prefix': '/install',
 'prefix': '/install',
 'srcdir': '.'}
